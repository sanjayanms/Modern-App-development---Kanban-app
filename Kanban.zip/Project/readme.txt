1) Open terminal
2) run local_setup.sh to install the virtual environment and essential libraries.
3) run local_run.sh to run the application.
4) run local_workers.sh to run the local workers.
