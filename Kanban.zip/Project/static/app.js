import login from "./components/login.js"
import kanban from "./components/kanban.js"


import sign_up from "./components/sign_up.js"
import logout from "./components/logout.js"
import logged_in from "./components/logged_in.js"
import login_failed from "./components/login_failed.js"
import success from "./components/success.js"
import error from "./components/error.js"


import changePassword from "./components/changePassword.js"


import user from "./components/user.js"

import list from "./components/list.js"
import home from "./components/home.js"
import summary from "./components/summary.js"

import card from "./components/card.js"
import addList from "./components/addList.js"
import addCard from "./components/addCard.js"
import listDetailsChange from "./components/listDetailsChange.js"
import moveCard from "./components/moveCard.js"
import cardChangeDetails from "./components/cardChangeDetails.js"







const routes =[
{ path : '/login', component : login,name:login},

{ path : '/kanban', component : kanban,name:kanban},
{path:'/changePassword',component:changePassword},

{ path : '/sign_up', component : sign_up,name:sign_up},
{path:'/logout',component:logout},
{path:'/logged_in',component:logged_in},
{ path : '/login_failed', component : login_failed,name:login_failed},
{path:'/success',component:success},

{path:'/error',component:error},

{ path : '/user_det', component : user,name:user},
{ path : '/list/:list_id', component : list, name:list},
{path : '/home',component : home,name:home},
{path : '/card/:list_id/:card_id',component : card,name:card},
{path:'/addlist', component : addList},
{path:'/addCard/:list_id', component : addCard, name:addCard},
{path:'/listDetailsChange/:list_id',component:listDetailsChange, name:listDetailsChange},
{path:'/moveCard/:card_id',component:moveCard,name:moveCard},
{path:'/cardChangeDetails/:list_id/:card_id',component:cardChangeDetails,name:cardChangeDetails},
{path : '/summary', component : summary,name:summary},
]

const router = new VueRouter({
	routes,
	base : '/home',
})

const app = new Vue({
	el : '#app',
	router,
	
})