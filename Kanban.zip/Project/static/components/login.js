import CustomFetch from "../CustomFetch.js"
const login ={
  template: `
<div>

        <br> </br>
        <br> </br>
        <br> </br>
        <div v-if="logged" class="card col-md-4">

          <p class="text-light bg-success"> logged in </p>

        </div>


        <div v-else align="center">

          <br> </br>

          <form  class="col-md-6" action='' >  
        
            <div class="form-outline mb-4">
              <label class="form-label" for="form4Example2">Email</label>

              <input type="text" id="form4Example2" class="form-control" name="email" v-model="formData.email"/>
              
            </div>

            <div class="form-outline mb-4">
              <label class="form-label" for="form4Example2">Password</label>

              <input type="password" id="form4Example2" class="form-control" name="password" v-model="formData.password"/>
              
            </div>


            <button @click="loginUser" type="submit" class="btn btn-primary btn-block mb-4" value="Login">Login</button>

          </form>

        </div>

</div>



  `,

  data() {
    return {
      formData: {
        email: "",
        password: "",
      },
      logged:null,
      error:null
    }
  },
   methods: {

  loginUser(){
      fetch('/login',{
      method: 'POST',       
      headers: {
          'Content-Type': 'application/json',
        },        
        body:JSON.stringify(this.formData),
      })
      .then(res=>res.json())
      .then((data)=>{localStorage.setItem("authentication-token",data.token);this.logged=true;this.$router.push('/logged_in')})
      
      .catch(this.$router.push('/login_failed'))

   
       
     
    }

   },
   beforeCreate(){

   }
}      
 







export default login