import CustomFetch from "../CustomFetch.js"
const moveCard = {
	template:`


<div align="center">
	<br>
	<div class="col-md-6">
		
		<div class="card w-75-card text-bg-secondary mb-3">
		  <div class="card-body">
		    <h5 class="card-title"> Move to </h5>
		    <br> </br>
		    <div align="center">

				<select class="form-select form-select-lg mb-3" aria-label=".form-select-lg example" v-model="list_id">			
					<option v-for="x in lists" v-bind:value="x.list_id" >{{x.name}}</option>
				</select>

			</div>
		  </div>
		</div>
		<a @click="moveCardtolist()" type="button" class="btn btn-primary btn-lg" >Submit</a>			

	</div>
</div>



	`,
	data(){
		return{
			lists:[],
			list_id:'',
		}
	},

	mounted(){
		CustomFetch(`/api/user`,{
			method:'GET',
			headers:{
				'authentication-token':localStorage.getItem('authentication-token'),
				'Content-Type':'application/json'
			}
		}).then((data) => {this.lists=data.lists})
	},
	methods:{
		moveCardtolist(){
			CustomFetch(`/api/card/${this.list_id}/${this.$route.params.card_id}`,{
				method:'put',
				headers:{
					'authentication-token':localStorage.getItem('authentication-token'),
					'Content-Type':'application/json'
				},
			}).then(this.$router.push(`/success`))

		}
	}


}
export default moveCard