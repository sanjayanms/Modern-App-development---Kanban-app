import CustomFetch from "../CustomFetch.js"
const addList={
	template : `

<div align="center">

				<nav class="navbar navbar-expand-lg navbar-light bg-light">
			  <div class="container-fluid">
			    <div class="collapse navbar-collapse" id="navbarSupportedContent">
			      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
			 
			        <li class="nav-item">
			          <a class="nav-link active" aria-current="page"><router-link to='/home'> Dashboard </router-link></a>
			        </li>
			 		</ul>
			      </form>
			    </div>
			  </div>
			</nav>

<br>
	<form  class="col-md-6" action="">	

	  <div class="form-outline mb-4">
	    <label class="form-label" for="form4Example2">List Name</label>

	    <input type="text" id="form4Example2" class="form-control" name="list_name" v-model="formData.name"/>
	    
	  </div>

	  <div class="form-outline mb-4">
	    <label class="form-label" for="form4Example3">About</label>

	    <textarea class="form-control" type="text" id="form4Example3" name="list_about" rows="4" v-model="formData.about"></textarea>
	  </div>

	  <button @click.prevent="createList" class="btn btn-primary btn-block mb-4"> Submit </button>

	</form>
</div>


	`,

	data(){
		return{
			formData:{
				name : "",
				about : "",
			}
		}
	},


	methods:{
		async createList(){
			if(this.formData.name){
			CustomFetch(`/api/list`,{
				method:'POST',
		  		headers: {
		          'Content-Type': 'application/json',
		          'authentication-token':localStorage.getItem('authentication-token')
		        },      	
		        body:JSON.stringify(this.formData),
       
			}).then(this.$router.push('/success'))}
		}
	}
}	

export default addList