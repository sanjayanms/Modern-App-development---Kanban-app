const error={
	template:`
<div align="center">
	<div class="col-md-6">		
		<div class="card w-75-card text-bg-secondary mb-3">
		  <div class="card-body">
		    <h5 class="card-title text-bg-danger"> Error </h5>
		    <br> </br>
		    <p class="card-text">Invalid values</p>
		    <br> <br> <br>

		  </div>
		</div>
	</div>
</div>
	`,


}


export default error