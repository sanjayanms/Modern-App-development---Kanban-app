const success={
	template:`
<div align="center">
				<nav class="navbar navbar-expand-lg navbar-light bg-light">
			  <div class="container-fluid">
			    <div class="collapse navbar-collapse" id="navbarSupportedContent">
			      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
			 
			        <li class="nav-item">
			          <a class="nav-link active" aria-current="page"><router-link to='/home'> Dashboard </router-link></a>
			        </li>
				</ul>
			      </form>
			    </div>
			  </div>
			</nav>

	<div class="col-md-6">		
		<div class="card w-75-card text-bg-secondary mb-3">
		  <div class="card-body">
		    <h5 class="card-title text-bg-success"> Message </h5>
		    <br> </br>
		    <p class="card-text">success</p>
		    <br> </br>

		  </div>
		</div>
	</div>
</div>
	`,

}

export default success