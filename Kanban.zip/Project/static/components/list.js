import CustomFetch from "../CustomFetch.js"


const list={
	
	template : `
	<div>
					<nav class="navbar navbar-expand-lg navbar-light bg-light">
			  <div class="container-fluid">
			    <div class="collapse navbar-collapse" id="navbarSupportedContent">
			      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
			 
			        <li class="nav-item">
			          <a class="nav-link active" aria-current="page"><router-link to='/home'> Dashboard </router-link></a>
			        </li>
			      </ul>  
			  
			      </form>
			    </div>
			  </div>
			</nav>
				  <div class="text-dark bg-dark" align="center">
				  
					<div class="card-group ">
						  <div class="card text-light bg-secondary">
						  		<div align="right">
									<div class="btn-group" role="group" aria-label="Basic mixed styles example">		  								
										<a @click="redirChangeDetails(list_details.list_id)" type="button" class="btn btn-dark" >Edit List Details</a>
										<a @click="deleteList(list_details.list_id)" type="button" class="btn btn-danger" >Delete List</a>	
									</div>
								</div>	
							    <div class="card-body ">
							    	<h1>{{list_details.name}}</h1>
									<br> </br>
							      	<p class="card-text">About : {{list_details.about}}</p>
									<div class="btn-group" role="group" aria-label="Basic mixed styles example">		  					
										<a @click="redirAddCard(list_details.list_id)" type="button" class="btn btn-light" >Add Task</a>							
									</div>
						    	</div>
							</div>
					</div>
				</div>	

				<div class="text-dark bg-dark" align="center">


						<div class="card-group ">


							<div class="card text-light bg-secondary">
							    	<div class="card-body ">
										<div class="card text-bg-primary mb-3" style="max-width: 18rem;">
										  <div class="card-header">Ongoing</div>
										 </div>				
										<div v-for="y in ongoing_cards">
											<div class="card text-bg-light mb-3" style="max-width: 18rem;">												  
											  <a @click="redirCard(list_details.list_id,y.card_id)" type="button" class="btn btn-dark">{{y.name}}</a>
											  <div class="card-body">
											    <p class="card-text">{{y.content}}</p>
											  </div>
											</div> 			    		
										</div>
									</div>
							</div>
					

							<div class="card text-light bg-secondary">
							    	<div class="card-body ">
										<div class="card text-bg-primary mb-3" style="max-width: 18rem;">
										  <div class="card-header">Completed</div>
										 </div>				
										<div v-for="y in completed_cards">
											<div class="card text-bg-light mb-3" style="max-width: 18rem;">												  
											  <a @click="redirCard(list_details.list_id,y.card_id)" type="button" class="btn btn-dark">{{y.name}}</a>
											  <div class="card-body">
											    <p class="card-text">{{y.content}}</p>
											  </div>
											</div> 			    		
										</div>
									</div>
							</div>


							<div class="card text-light bg-secondary">
							    	<div class="card-body ">
										<div class="card text-bg-primary mb-3" style="max-width: 18rem;">
										  <div class="card-header">Overdue</div>
										 </div>				
										<div v-for="y in overdue_cards">
											<div class="card text-bg-light mb-3" style="max-width: 18rem;">												  
											  <a @click="redirCard(list_details.list_id,y.card_id)" type="button" class="btn btn-dark">{{y.name}}</a>
											  <div class="card-body">
											    <p class="card-text">{{y.content}}</p>
											  </div>
											</div> 			    		
										</div>
									</div>
							</div>

						</div>	


					</div>	
		<br>			

					<div v-if="export_link">
						<a v-bind:href="export_link"> Download csv </a>
					</div>
					<div v-else> 
						<a @click="export_summary" type="button" class="btn btn-warning btn-lg">export details as csv </a>
					</div>

				</div>	



	</div>

	`
		,
	
	data(){
		return{
			list_details:{},
			cards:[],
			export_link:null,
		}
	},


	mounted(){
		CustomFetch(`/api/list/${this.$route.params.list_id}`,{
			method:'GET',
			headers:{
				'authentication-token':localStorage.getItem('authentication-token'),
				'Content-Type':'application/json'
			}
		}).then((data) => {
			this.list_details=data.list_details;
			this.cards=data.list_details.cards
		})
		
	},

	

	methods:{
		redirCard(a,b){
			this.$router.push(`/card/${a}/${b}`)
		},
		redirAddCard(a){
			this.$router.push(`/addCard/${a}`)
		},
		deleteList(a){
			CustomFetch(`api/list/${a}`,{
				method:'Delete',
				headers:{
					'authentication-token':localStorage.getItem('authentication-token'),
					'Content-Type':'application/json'
				},				
			}).then((data)=>{this.$router.push(`/success`)})
		},
		redirChangeDetails(a){
			this.$router.push(`/listDetailsChange/${a}`)
		},

		export_summary(){
			CustomFetch(`/export_list_summary/${this.$route.params.list_id}`,{
				method:'GET',
				headers:{
					'authentication-token':localStorage.getItem('authentication-token'),
					'Access-Control-Expose-Headers': 'Content-Disposition'

				}			
			}).then((data)=>{this.export_link=data.link})
		}	


	},

	computed:{
		completed_cards(){
		 return this.cards.filter((x) => {return x.completed != 'no'})
		},
		ongoing_cards(){
		 return this.cards.filter((x) => {return x.completed == 'no'})
		},
		overdue_cards(){
		 return this.cards.filter((x) => {return new Date(x.deadline) < new Date() & x.completed == 'no'})			
		}

	}


}









export default list