import CustomFetch from "../CustomFetch.js"
const logout={
	template:``,

	mounted(){
		localStorage.removeItem('authentication-token')
		this.$router.push('/kanban')
	}
}
export default logout