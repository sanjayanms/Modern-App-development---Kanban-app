import CustomFetch from "../CustomFetch.js"

const summary={
	template:`

<div align="center">
				<nav class="navbar navbar-expand-lg navbar-light bg-light">
			  <div class="container-fluid">
			    <div class="collapse navbar-collapse" id="navbarSupportedContent">
			      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
			 
			        <li class="nav-item">
			          <a class="nav-link active" aria-current="page"><router-link to='/home'> Dashboard </router-link></a>
			        </li>
					</ul>
			      </form>
			    </div>
			  </div>
			</nav>

	<div class="col-md-8">
		<div class="card w-50-card text-bg-secondary mb-3">
		  <div class="card-body">

		  	<h5 class="card-title">Summary</h5>
		    <br> </br>
						<img :src="'static/graphs/'+user_id+'.jpg'">

			<br> </br>

				<table class="table table-dark table-striped">

					 <tbody>
					    <tr>
					      <th scope="row">1</th>
					      <td>Total number of Lists</td>
					      <td>{{totalLists}}</td>
					    </tr>
					    <tr>
					      <th scope="row">2</th>
					      <td>Total number of Tasks</td>
					      <td>{{totalCards}}</td>
					    </tr>
					    <tr>
					      <th scope="row">2</th>
					      <td>Total number of Tasks completed</td>
					      <td>{{cardsCompleted}}</td>
					    </tr>
					    <tr>
					      <th scope="row">2</th>
					      <td>Total number of Tasks overdue</td>
					      <td>{{cardsOverdue}}</td>
					    </tr>					    					    
				
					    <tr>
					      <th scope="row">3</th>
					      <td>Efficiency ( Proportion of tasks completed on time )</td>

					      <td> {{efficiency}}%</td>
					  
					    </tr>


					  </tbody>
				</table>

			</div>
		</div>
	</div>

	<div v-if="export_link">
		<a v-bind:href="export_link"> Download csv </a>
	</div>
	<div v-else> 
		<a @click="export_summary" type="button" class="btn btn-warning btn-lg">export Summary as csv </a>
	</div>
	<br> <br>
	<h5 class="card-title"> List wise Summary</h5>

	<div class="text-light-bg-secondary" v-for="x in lists">
		<img :src="'static/graphs/'+user_id+'_'+x.list_id+'.jpg'">
	</div>




</div>	

			

	`,
	data(){
		return{
			lists:[],
			export_link:null,
			user_id:-1,
			links:[]
		}

	},


	created(){
		CustomFetch(`/api/user`,{
			method:'GET',
			headers:{
				'authentication-token':localStorage.getItem('authentication-token'),
				'Content-Type':'application/json'
			}
		}).then((data) => {this.lists=data.lists,this.user_id=data.user_id}),
		CustomFetch(`/summary`,{
			method:'GET',
			headers:{
				'authentication-token':localStorage.getItem('authentication-token'),
				'Content-Type':'application/json'
			}
		})
		

		
	},

	computed:{
		totalLists(){
			return this.lists.length
		},
		totalCards(){
			let num=0;
			this.lists.forEach((obj)=>{num+=obj.cards.length})
			return num
		},
		cardsCompleted(){
			let num=0
			this.lists.forEach((obj)=>{obj.cards.forEach((card)=>{if(card.completed!='no'){num++}})})
			return num
		},
		cardsOverdue(){
			let num=0
			this.lists.forEach((obj)=>{obj.cards.forEach((card)=>{if(new Date(card.deadline) < new Date() & card.completed=='no'){num++}})})
			return num
		},

		efficiency(){
			let num=0
			this.lists.forEach((obj)=>{obj.cards.forEach((card)=>{if(card.completed!='no'){if(new Date(card.completed) <= new Date(card.deadline)){num++}}})})
			return (num/this.cardsCompleted*100).toFixed(2)


		},


	},
	methods:{
		export_summary(){
			CustomFetch(`/export_details`,{
				method:'GET',
				headers:{
					'authentication-token':localStorage.getItem('authentication-token'),
					'Access-Control-Expose-Headers': 'Content-Disposition'

				}			
			}).then((data)=>{this.export_link=data.link})
		},
		getLink(list_id){
			return 'static/graphs'+this.user_id+'_'+list_id

		}

	}	

}
export default summary