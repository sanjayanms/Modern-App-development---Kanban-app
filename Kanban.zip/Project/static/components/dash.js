const dash = {
	template : `
	<div> 
		<br> <br>
		Welcome to dash 
		<p v-for='x in lists'> {{x}} </p>
	</div>`,

data() {
	return {
		lists:[{"lis_id":1,"lis_name":"Project1","lis_about":"",},{"lis_id":2,"lis_name":"Project2","lis_about":"",},{"lis_id":3,"lis_name":"Project3","lis_about":"",}],
		cards:[{"lis_id":1,"card_name":"card1","card_content":'',"deadline":'21/10/1998',"completed":'no'},{"lis_id":3,"card_name":"card2","card_content":'',"deadline":'26/10/1998',"completed":'yes'}]

	}
},
async mounted(){
	const res = await fetch('/api/list/1')
	if(res.ok){
		const data = await res.json()
		this.lists=data
	}
}

}

export default dash