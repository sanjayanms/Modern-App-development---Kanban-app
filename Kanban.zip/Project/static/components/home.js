import CustomFetch from "../CustomFetch.js"

const home = {
	template : `<div>


	
				<div v-if="logged" >


				<nav class="navbar navbar-expand-lg navbar-light bg-light">
			  <div class="container-fluid">
			    <div class="collapse navbar-collapse" id="navbarSupportedContent">
			      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
			 
			        <li class="nav-item">
			          <a class="nav-link active" aria-current="page"><router-link to='/home'> Dashboard </router-link></a>
			        </li>
			        <li class="nav-item">
			          <a class="nav-link active"><router-link to='/addList'> Add List </router-link></a>
			        </li>
			        
			        <li class="nav-item">
			          <a class="nav-link active" tabindex="-1" aria-disabled="true"><router-link to='/summary'> Summary </router-link></a>
			        </li>
			      </ul>
			      <form class="d-flex" action=''>

	        		<input class="form-control me-2" type="search" placeholder="Search task" aria-label="Search" name="card_name" v-model="search_key">
	        		<button @click="search" class="btn btn-outline-success" type="submit">Search</button>
			      	

			        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
		 				<li class="nav-item">
				          <a class="nav-link active" tabindex="-1" aria-disabled="true"><router-link to='/user_det'> User </router-link></a>
				        </li>			        	
				        <li class="nav-item">
				        	<a class="nav-link"><router-link to='/logout'> Logout </router-link></a>
				        </li>
			      	</ul> 
			      </form>
			    </div>
			  </div>
			</nav>
			<br> <br>
							<div class="card-group">



								<div class="card text-light bg-secondary" v-for = "x in lists">
									<div class="card-body ">
										<a @click="redirList(x.list_id)" type="button" class="btn btn-warning btn-lg">{{x.name}} </a>
			    						<p class="card-text">About : {{x.about}}</p>
										<div class="btn-group" role="group" aria-label="Basic mixed styles example">				
											<a @click="redirAddCard(x.list_id)" type="button" class="btn btn-light">Add Task</a>
										</div>

									</div>

									<div v-for="y in x.cards">
											<br> </br>						
											<div class="card text-bg-light mb-3" style="max-width: 18rem;">													  
												<a @click="redirCard(x.list_id,y.card_id)" type="button" class="btn btn-dark">{{y.name}}</a>
													<div class="card-body">
														<p class="card-text">{{y.content}}</p>
													</div>										  
											</div>					
									</div>


								</div>





	
								</div>	
							</div>	
					<div v-else>
						<br>
						<br>

						<a @click="redirLogin" type="button" class="btn btn-warning btn-lg">login </a>
					</div>

				</div>	`



		,
	
	data(){
		return{
			lists:[],
			logged:null,
			search_key:'',
		}
	},


	created(){
		console.log(localStorage.getItem('authentication-token')),
		CustomFetch(`/api/user`,{
			method:'GET',
			headers:{
				'authentication-token':localStorage.getItem('authentication-token'),
				'Content-Type':'application/json'
			}
		})
		.then((data) => {this.lists=data.lists;localStorage.setItem('username',data.username);this.logged=true})
		.catch(this.logged=false,console.log(this.logged))
	},
	methods:{
		redirCard(a,b){
			this.$router.push(`/card/${a}/${b}`)
		},
		redirList(a){
			this.$router.push(`/list/${a}`)
		},
		redirAddCard(a){
			this.$router.push(`/addCard/${a}`)
		},
		redirLogin(){
			this.$router.push(`/login`)
		},
		logout(){
			localStorage.remove("authentication-token")
			this.$router.push(`/login`)
		},
		search(){
			let l_id=''
			let c_id=''
			this.lists.forEach((obj)=>{obj.cards.forEach((card)=>{if(this.search_key==card.name){l_id=obj.list_id;c_id=card.card_id}})})
			console.log(l_id,c_id)
			if(l_id && c_id){
				this.$router.push(`card/${l_id}/${c_id}`)
			}
			else{
				this.$router.push('/error')
			}
		}		

	},	


}
 
 
export default home