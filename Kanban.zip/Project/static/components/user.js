
const user={
	template:`

	<div align="center">
				<nav class="navbar navbar-expand-lg navbar-light bg-light">
			  <div class="container-fluid">
			    <div class="collapse navbar-collapse" id="navbarSupportedContent">
			      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
			 
			        <li class="nav-item">
			          <a class="nav-link active" aria-current="page"><router-link to='/home'> Dashboard </router-link></a>
			        </li>
			      </ul>
			      </form>
			    </div>
			  </div>
			</nav>	
		<br>

		<div class="col-md-3">
			<div class="card w-50-card text-bg-secondary mb-3">
			  <div class="card-body">
			    <h5 class="card-title">User</h5>
			    <br> 
			    <p class="card-text ">{{username}}</p>
			   	</br>
			 

			  </div>
			</div>
		</div>
	    <button @click="changePassword" type="submit" class="btn btn-primary btn-block mb-4" >Change password</button>
	
	</div>


	`,
	data(){
		return{
			username:'aad'
		}

	},
	mounted(){
		this.username=localStorage.getItem('username')
	},
	methods:{
		changePassword(){
			this.$router.push('/changePassword')
		}
	}


}
export default user