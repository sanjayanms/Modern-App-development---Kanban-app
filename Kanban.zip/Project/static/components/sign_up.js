import CustomFetch from "../CustomFetch.js"
const sign_up ={
  template: `
<div>

        <br> </br>
        <br> </br>
        <br> </br>
   


        <div align="center">

          <br> </br>

          <form  class="col-md-6" action='' >  

            <div class="form-outline mb-4">
              <label class="form-label" for="form4Example2">Username</label>

              <input type="text" id="form4Example2" class="form-control" name="email" v-model="formData.username"/>
              
            </div>          
        
            <div class="form-outline mb-4">
              <label class="form-label" for="form4Example2">Email</label>

              <input type="text" id="form4Example2" class="form-control" name="email" v-model="formData.email"/>
              
            </div>

            <div class="form-outline mb-4">
              <label class="form-label" for="form4Example2">Password</label>

              <input type="password" id="form4Example2" class="form-control" name="password" v-model="formData.password"/>
              
            </div>


            <button @click="signup" type="submit" class="btn btn-primary btn-block mb-4" value="sign up">Signup</button>

          </form>

        </div>

</div>



  `,

  data() {
    return {
      formData: {
        email: "",
        password: "",
        username:"",
      },
      logged:null,
      error:null
    }
  },
   methods: {

  signup(){
      if(this.formData.password && this.formData.username && this.formData.email && this.formData.email.includes("@") && this.formData.email.includes(".com")){
        CustomFetch('/api/user',{
        method: 'POST',       
        headers: {
            'Content-Type': 'application/json',
          },        
          body:JSON.stringify(this.formData),
        })
        .then((data)=>{if(data.result=='success'){this.$router.push('/success')} else{this.$router.push('/error')}})
        .catch(this.$router.push('/error'))  

      }
      else{
        return this.$router.push('/error')
      }
  

   
       
     
    }

   },
   beforeCreate(){

   }
}      
 







export default sign_up