import CustomFetch from "../CustomFetch.js"

const card = {
	template : `
<div align="center">
				<nav class="navbar navbar-expand-lg navbar-light bg-light">
			  <div class="container-fluid">
			    <div class="collapse navbar-collapse" id="navbarSupportedContent">
			      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
			 
			        <li class="nav-item">
			          <a class="nav-link active" aria-current="page"><router-link to='/home'> Dashboard </router-link></a>
			        </li>
					</ul>
			      </form>
			    </div>
			  </div>
			</nav>


	<div align="right">
		<div class="btn-group" role="group" aria-label="Basic mixed styles example">
			<a @click="redirMoveCard" type="button" class="btn btn-dark" >Move Task</a>		
			<a @click="cardDelete" type="button" class="btn btn-danger">Delete Task</a>
		</div>
	</div>	
	<a @click="redirListDetails(card_details.list_id)" type="button" class="btn btn-warning btn-lg" >{{ card_details.list_name }}</a>
	<br> </br>
	<div class="col-md-3">
		<div class="card w-50-card text-bg-secondary mb-3">
		  <div class="card-body">
		    <h5 class="card-title">Task Name</h5>
		    <br> 
		    <p class="card-text ">{{card_details.name}}</p>
		   	</br>
		  </div>
		</div>
	</div>
	<div class="col-md-6">		
		<div class="card w-75-card text-bg-secondary mb-3">
		  <div class="card-body">
		    <h5 class="card-title"> Task Content </h5>
		    <br> </br>
		    <p class="card-text">{{card_details.content}}</p>
		    <br> </br>
		    <a @click="changeDetails" class="btn btn-dark">Edit Details</a>

		  </div>
		</div>
	</div>
	<p style="color:orange">Deadline : {{card_details.deadline}}</p>

	<div v-if="card_details.completed=='no'">
		<a @click="makeCompleted" type="button" class="btn btn-success btn-lg" >Mark Completed</a>
	</div>
	<div v-else>	

		<p style="color:green">Completed on : {{card_details.completed}} </p>
	</div>
</div>

	`,

	data(){
		return{
			card_details:{},
		}
	},

	mounted(){
		CustomFetch(`/api/card/${this.$route.params.list_id}/${this.$route.params.card_id}`,{
			method:'GET',
			headers:{
				'authentication-token':localStorage.getItem('authentication-token'),
				'Content-Type':'application/json'
			}
		}).then((data)=>{this.card_details=data})

	},

	methods:{
		redirListDetails(a){
			this.$router.push(`/list/${a}`)
		},
		redirMoveCard(){
			this.$router.push(`/moveCard/${this.$route.params.card_id}`)
		},
		makeCompleted(){
			CustomFetch(`api/card/${this.card_details.list_id}/${this.$route.params.card_id}`,{
				method:"patch",
				headers:{
					'authentication-token':localStorage.getItem('authentication-token'),
					'Content-Type':'application/json'
				},
			}).then(this.$router.push('/success'))
		},
	cardDelete(){
			CustomFetch(`api/card/${this.card_details.list_id}/${this.$route.params.card_id}`,{
				method:'delete',
				headers:{
					'authentication-token':localStorage.getItem('authentication-token'),
					'Content-Type':'application/json'
				},
			}).then(this.$router.push('/success'))
		},

	changeDetails(){
		this.$router.push(`/cardChangeDetails/${this.card_details.list_id}/${this.$route.params.card_id}`)


		}			
	}

}
export default card