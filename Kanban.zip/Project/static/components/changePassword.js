import CustomFetch from "../CustomFetch.js"

const changePassword={
	template : `
<div align="center">
				<nav class="navbar navbar-expand-lg navbar-light bg-light">
			  <div class="container-fluid">
			    <div class="collapse navbar-collapse" id="navbarSupportedContent">
			      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
			 
			        <li class="nav-item">
			          <a class="nav-link active" aria-current="page"><router-link to='/home'> Dashboard </router-link></a>
			        </li>
				</ul>
			      </form>
			    </div>
			  </div>
			</nav>
<br>
	<form  class="col-md-6" action="">	



	  <div class="form-outline mb-4">
	    <label class="form-label" for="form4Example3">Old password</label>

	    <input type="password" id="form4Example2" class="form-control" name="old_password" v-model="formData.old_password"/>
	  </div>
	  <div class="form-outline mb-4">
	    <label class="form-label" for="form4Example3">New password</label>

	    <input type="password" id="form4Example2" class="form-control" name="new_password" v-model="formData.new_password"/>
	  </div>	  

	
	</form>
	  <button @click.prevent="changeDetails" class="btn btn-primary btn-block mb-4"> Submit </button>

</div>

	`,

	data(){
		return{
			formData:{
				old_password:"",
				new_password:"",

			},
		}
	},


	methods:{
		changeDetails(){
				CustomFetch(`/api/user`,{
					method:"put",
			  		headers: {
			          'Content-Type': 'application/json',
			          'authentication-token':localStorage.getItem('authentication-token')
			        },      	
			        body:JSON.stringify(this.formData),
	       
				}).then((data)=>{if(data.result=='success'){this.$router.push('/success')} else{this.$router.push('/error')}})
			
		}
	}	


}
export default changePassword