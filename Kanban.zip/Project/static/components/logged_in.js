const logged_in={
	template:`
<div align="center">
	<div class="col-md-6">		
		<div class="card w-75-card text-bg-secondary mb-3">
		  <div class="card-body">
		    <h5 class="card-title text-bg-success"> Message </h5>
		    <br> </br>
		    <p class="card-text">Logged in successfully</p>
		    <br> </br>

		  </div>
		</div>
	</div>
	<a @click="redirHome" type="button" class="btn btn-warning">Go to Dashboard</a>

</div>
	`,
	methods:{
		redirHome(){
			this.$router.push('/home')
		}
	}
}


export default logged_in