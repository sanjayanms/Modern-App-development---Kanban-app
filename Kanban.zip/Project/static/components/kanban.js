const kanban={
	template:`
	<div>
	
				<nav class="navbar navbar-expand-lg navbar-light bg-light">
			  <div class="container-fluid">
			    <div class="collapse navbar-collapse" id="navbarSupportedContent">
			      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
			 
			        <li class="nav-item">
			          <a class="nav-link active" aria-current="page"><router-link to='/home'> My Account </router-link></a>
			        </li>
			        <li class="nav-item">
			          <a class="nav-link active"><router-link to='/login'> Login </router-link></a>
			        </li>
     				<li class="nav-item">
			          <a class="nav-link active"><router-link to='/sign_up'> Sign up </router-link></a>
			        </li>	
			      </ul>  		        
			 
			      </form>
			    </div>
			  </div>
			</nav>


	</div>

	`,

	methods:{
		redirLogin(){
			this.$router.push('/login')
		},
		redirHome(){
					this.$router.push('/home')
		},
		redirSignup(){
					this.$router.push('/sign_up')
		}		

	}
}
export default kanban