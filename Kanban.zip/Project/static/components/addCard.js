import CustomFetch from "../CustomFetch.js"

const addCard={
	template : `
<div align="center">
				<nav class="navbar navbar-expand-lg navbar-light bg-light">
			  <div class="container-fluid">
			    <div class="collapse navbar-collapse" id="navbarSupportedContent">
			      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
			 
			        <li class="nav-item">
			          <a class="nav-link active" aria-current="page"><router-link to='/home'> Dashboard </router-link></a>
			        </li>
		sanjayanms1998@gmail.com21
			      </form>
			    </div>
			  </div>
			</nav>
<br>
	<form  class="col-md-6" action="">	

	  <div class="form-outline mb-4">
	    <label class="form-label" for="form4Example2">Card Name</label>

	    <input type="text" id="form4Example2" class="form-control" name="list_name" v-model="formData.name"/>
	    
	  </div>

	  <div class="form-outline mb-4">
	    <label class="form-label" for="form4Example3">Content</label>

	    <textarea class="form-control" type="text" id="form4Example3" name="list_about" rows="4" v-model="formData.content"></textarea>
	  </div>

	  <div class="form-outline mb-4">
	    <label class="form-label" for="form4Example2">Deadline</label>

	    <input type="date" id="form4Example2" class="form-control" name="card_deadline" v-model="formData.deadline"/>
	      
	   </div>	  

	  <button @click.prevent="createCard" class="btn btn-primary btn-block mb-4"> Submit </button>
	</form>
</div>

	`,

	data(){
		return{
			formData:{
				name:'',
				content:'',
				deadline:'',
			}
		}
	},
	methods:{
		createCard(){
			if(this.formData.name && this.formData.deadline){
			CustomFetch(`/api/card/${this.$route.params.list_id}`,{
				method:'POST',
		  		headers: {
		          'Content-Type': 'application/json',
		          'authentication-token':localStorage.getItem('authentication-token')
		        },      	
		        body:JSON.stringify(this.formData),
       
			}).then(this.$router.push('/success'))}
		}
	}	


}
export default addCard