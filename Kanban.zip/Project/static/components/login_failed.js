const login_failed={
	template:`
<div align="center">
	<div class="col-md-6">		
		<div class="card w-75-card text-bg-secondary mb-3">
		  <div class="card-body">
		    <h5 class="card-title text-bg-danger"> Error </h5>
		    <br> </br>
		    <p class="card-text">Invalid credentials.</p>
		    <br> <br> <br>
		    <a @click="redirLogin" type="button" class="btn btn-dark btn-lg" >Login again</a>

		  </div>
		</div>
	</div>
</div>
	`,

	methods:{

		redirLogin(){
			this.$router.push(`/login`)
		},
	}	

}


export default login_failed