from flask import Flask
from flask_apscheduler import APScheduler
from application.api.resource import UserAPI,ListAPI,api,cache
from application import config
from application import workers
from application import tasks
from application.tasks import mail
from application.config import LocalDevelopmentConfig
from application.models import db,User,List,Card






def create_app():
	app=Flask(__name__,template_folder="templates")
	app.config.from_object(LocalDevelopmentConfig)
	db.init_app(app)
	api.init_app(app)
	app.app_context().push()

	celery=workers.celery
	celery.conf.update(
		broker_url=app.config["CELERY_BROKER_URL"],
		result_backend=app.config["CELERY_RESULT_BACKEND"]
	)	
	celery.Task=workers.ContextTask
	app.app_context().push()

	cache.init_app(app)
	app.app_context().push()

	mail.init_app(app)
	app.app_context().push()
	
	sch=APScheduler()
	app.app_context().push()


	return app,api,celery,cache,mail,sch

app,api,celery,cache,mail,sch=create_app()


from application.controllers import *

if (__name__=="__main__"):
	sch.add_job(id="send_mail",func=send_mail,trigger='cron',hour=16,minute=0,day=1)
	sch.add_job(id='daily_report',func=send_daily_report,trigger='cron',hour=17,minute=0)
	sch.start()
	app.run(host="0.0.0.0",port=8080,debug=True)


