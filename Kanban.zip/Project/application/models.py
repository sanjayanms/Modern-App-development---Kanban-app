from .database import db


class User(db.Model):
	__tablename__="user"
	user_id=db.Column(db.Integer(),primary_key=True,autoincrement=True)
	email=db.Column(db.String(),nullable=False,unique=True)
	username=db.Column(db.String(),nullable=False)
	password=db.Column(db.String(),nullable=False)
	lis=db.relationship("List",backref="superlist")

class List(db.Model):
	__tablename__="list"
	list_id=db.Column(db.Integer(),primary_key=True,autoincrement=True)
	name=db.Column(db.String(),nullable=False)
	about=db.Column(db.String())
	user_id=db.Column(db.Integer(),db.ForeignKey('user.user_id'))
	card=db.relationship("Card",backref="superlist")

class Card(db.Model):
	__tablename__="cards"
	card_id=db.Column(db.Integer(),primary_key=True)
	name=db.Column(db.String(),nullable=False)
	content=db.Column(db.String())
	l_id=db.Column(db.Integer(),db.ForeignKey('list.list_id'),nullable=False)
	deadline=db.Column(db.String(),nullable=False)
	completed=db.Column(db.String(),default='no')

