import jwt
from flask import Flask,render_template,request,jsonify,current_app,make_response
from functools import wraps
from application.models import db,User






def token_required(f):
	@wraps(f)
	def decorated(*args,**kwargs):
		token=None
		
		if 'authentication_token' in request.headers:
			token=request.headers['authentication_token']
		if(not token):
			return make_response(jsonify({'message':'Token is missing'}),401)				
		try:
			data=jwt.decode(token,current_app.config['SECRET_KEY'], algorithms=["HS256"])
			current_user=User.query.filter(User.email==data['email']).first()
		except:
			return make_response(jsonify({'message':'Invalid token'}),401)

		return f(current_user,*args,**kwargs)	
	
	return decorated			













	'''	token=request.headers['auth_token']
		if(not token):
			return jsonify({'message':'Token is missing'}),401
		try:
			data=jwt.decode(token,current_app.config['SECRET_KEY'], algorithms=["HS256"])
		except:
			return jsonify({'message':'Invalid token'}),401
		return f(*args,**kwargs)	
	return decorated	'''