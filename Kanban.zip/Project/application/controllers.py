import os
import matplotlib.pyplot as plt
from flask import Flask,render_template,request,jsonify,make_response,send_file,render_template,current_app as app
from flask_apscheduler import APScheduler

from application.api.resource import UserAPI,ListAPI,api,cache
from application import config

from application import workers
from application import tasks
from application.tasks import mail
from application.config import LocalDevelopmentConfig
from application.models import db,User,List,Card

import jwt
import datetime
from dateutil import parser
import random
from functools import wraps
from application.api.resource import cache


from werkzeug.security import generate_password_hash, check_password_hash

from application.security.security import token_required
@app.route('/login',methods=['POST'])
def login():
	try:	
		body=request.get_json()
		print(body['email'],body['password'])
		user=User.query.filter(User.email==body['email']).one()
		if(check_password_hash(user.password,body['password'])):

			token=jwt.encode({'email':body['email'],'exp':datetime.datetime.utcnow()+datetime.timedelta(hours=6)},app.config['SECRET_KEY'])

			return make_response(jsonify({"token":token}),200)

		else:
			return 'wrong password'	
	except:
		return 'Not authorised'			


@app.route('/hello')
def hello():
	job=tasks.say_hello.delay()
	while( not job.result):
		continue
	return send_file("exported/Names.csv")

@app.route('/export_details')
@token_required
def export_details(self):
	job=tasks.export_details.delay(self.user_id)
	while(not job.result):
		continue
	token=request.headers['authentication_token']	
	return 	jsonify({'link':"http://127.0.0.1:8080/download/summary/"+token+"/"+f'{self.user_id}'})

@app.route('/export_list_summary/<list_id>')
@token_required
def export_list_summary(self,list_id):
	job=tasks.export_list_details.delay(self.user_id,list_id)
	while(not job.result):
		continue
	token=request.headers['authentication_token']	
	return 	jsonify({'link':"http://127.0.0.1:8080/download/list_summary/"+token+"/"+f'{self.user_id}'+"/"+f'{list_id}'})




@app.route('/download/<info>/<token>/<user_id>')
def download(info,token,user_id):
	try:

		data=jwt.decode(token,app.config['SECRET_KEY'], algorithms=["HS256"])
		current_user_id=User.query.filter(User.email==data['email']).first().user_id
		if(int(current_user_id)==int(user_id)):
			if(info=='summary'):
				return send_file('exported/'+'summary_'+f'{user_id}'+'.csv')
			else:
				return 	'ss'		
		return 'error 1'	
	except:
		return 'error'		

@app.route('/download/list_summary/<token>/<user_id>/<list_id>')
def download_list(token,user_id,list_id):
	data=jwt.decode(token,app.config['SECRET_KEY'], algorithms=["HS256"])
	current_user_id=User.query.filter(User.email==data['email']).first().user_id
	if(int(current_user_id)==int(user_id)):	
		return send_file('exported/'+'list_summary_'+f'{user_id}_'+f'{list_id}'+'.csv')
	else:
		return 'error'	

@app.route('/summary')
@token_required
@cache.cached(timeout=5)
def summary(self):
	print('___summary____')
	qlist=List.query.filter(List.user_id==self.user_id).all()
	l=[]

	upcoming=0
	passedafterdue=0
	passedbeforedue=0
	ncafterdue=0
	ncbeforedue=0


	today=datetime.datetime.today()
	for x in qlist:
		y=Card.query.filter(x.list_id==Card.l_id).all()
		l.append(x.list_id)

		cur_passedafterdue=0
		cur_passedbeforedue=0
		cur_ncafterdue=0
		cur_ncbeforedue=0
		for z in y:

			dead=parser.parse(z.deadline)

			if(z.completed!='no'):
				cdate=parser.parse(z.completed)
				if((cdate-dead).days>0):
					cur_passedafterdue+=1
				else:
					cur_passedbeforedue+=1
			else:
				if((today-dead).days>0):
					cur_ncafterdue+=1
				else:
					cur_ncbeforedue+=1
				if((dead-today).days<=7 and (dead-today).days>=0):
					upcoming+=1	
			


		cur_total_pass=cur_passedafterdue+cur_passedbeforedue
		cur_ongoing=cur_ncbeforedue+cur_ncafterdue
		cur_data=[cur_total_pass,cur_ongoing,cur_ncafterdue]
		plt.figure(random.randint(1,100))
		xlabel=["Completed","Ongoing","Overdue"]
		plt.ylabel("Number of tasks")
		plt.title(x.name)
		plt.bar(xlabel,cur_data,color='maroon')

	
		plt.savefig("static/graphs/"+f'{self.user_id}_'+f'{x.list_id}'+".jpg")



		passedafterdue+=cur_passedafterdue
		passedbeforedue+=cur_passedbeforedue
		ncafterdue+=cur_ncafterdue
		ncbeforedue+=cur_ncbeforedue		

			


	total_pass=passedafterdue+passedbeforedue
	ongoing=ncbeforedue+ncafterdue	
	data=[total_pass,ongoing,ncafterdue]
	plt.figure(random.randint(1,100))
	xlabel=["Completed","Ongoing","Overdue"]
	plt.ylabel("Number of tasks")
	plt.bar(xlabel,data,color='g')

	plt.savefig("static/graphs/"+str(self.user_id)+".jpg")

	d={}
	d['user_id']=self.user_id
	d["total_tasks"]=passedafterdue+passedbeforedue+ncafterdue+ncbeforedue
	d['total_completed']=total_pass
	d['total_overdue']=ncafterdue
	d['upcoming']=upcoming
	try:
		d["efficiency"]=f'{passedbeforedue/(passedafterdue+passedbeforedue)*100}%'
	except:
		d['efficiency']="None"	



	return jsonify({"details":d})



def send_mail():
	job=tasks.send_mail.delay()
	while(not job.result):
		continue
	return 'done'

def send_daily_report():
	job=tasks.daily_report.delay()
	while(not job.result):
		continue
	return 'done'	




@app.route('/')
def home():
	return render_template('index.html')

