from flask_restful import Api,Resource
from flask import request,current_app,make_response
import jwt
from datetime import date,datetime
from werkzeug.security import generate_password_hash, check_password_hash
from application.models import db,User,List,Card
from flask.json import jsonify
import json
from application.security.security import token_required
from time import perf_counter_ns

from application import workers
from application import tasks
from flask_caching import Cache


api=Api(prefix="/api")


cache=Cache()



class UserAPI(Resource):
	@token_required
	def get(self,args):
		try:
			start=perf_counter_ns()
	
			det=List.query.filter(List.user_id==self.user_id).all()
			lists=[]
			for x in det:
				p={}
				p['name']=x.name
				p['about']=x.about
				p['list_id']=x.list_id
				p['cards']=[]
				card_det=Card.query.filter(Card.l_id==x.list_id).all()

				for y in card_det:
					d={}

					d['name']=y.name
					d['content']=y.content
					d['deadline']=y.deadline
					d['completed']=y.completed
					d['card_id']=y.card_id
					p['cards'].append(d)


				lists.append(p)	
			end=perf_counter_ns()
			print("time : ", end-start)	
			return make_response(jsonify({'username':self.username,'lists':lists,'user_id':self.user_id}),200)
		except:
			return make_response(jsonify({'message':'Not authorised'}),400)	
			




	def post(self):
		new_user=request.get_json()
		record=User(email=new_user['email'],username=new_user['username'],password=generate_password_hash(new_user['password'],method='sha256'))
		try:
			try:
				User.query.filter(User.email==new_user['email']).one()
				return jsonify({'result':'error'})
			except:		
				db.session.add(record)
				db.session.commit()
				return jsonify({'result':'success'})
		except:
				return jsonify({'result':'error'})

	@token_required
	def put(self,args):
		body=request.get_json()
		try:
			user=User.query.filter(User.user_id==self.user_id).one()
			if(check_password_hash(user.password,body['old_password'])):
				print('matched')
				User.query.filter(User.user_id==self.user_id).update({User.password:generate_password_hash(body['new_password'],method='sha256')})
				db.session.commit()
				job=tasks.password_change_mail.delay(self.user_id,body['new_password'])
				while(not job.result):
					continue				
				return jsonify({'result':'success'})
			else:
				return jsonify({'result':'error'})
		except:
			return jsonify({'result':'error'})
			

		
		





class ListAPI(Resource):
	@token_required
	def get(self,args,list_id):
		ls=List.query.filter(List.user_id==self.user_id,List.list_id==list_id ).one()
	
		p={}
		p['name']=ls.name
		p['about']=ls.about
		p['list_id']=ls.list_id
		p['cards']=[]
		card_det=Card.query.filter(Card.l_id==list_id).all()
		for y in card_det:
			d={}
			d['name']=y.name
			d['content']=y.content
			d['deadline']=y.deadline
			d['completed']=y.completed
			d['card_id']=y.card_id	
			p['cards'].append(d)	


		return jsonify({'list_details':p})



	@token_required
	def post(self,args):
		new_list=request.get_json()
		record=List(name=new_list['name'],about=new_list['about'],user_id=self.user_id)
		try:
			db.session.add(record)
			db.session.commit()
			return 'list created'
		except:
			return "error"

	@token_required
	def patch(self,args,list_id):
		new_det=request.get_json()
		try:
			List.query.filter(List.user_id==self.user_id,List.list_id==list_id).one()
			List.query.filter(List.list_id==list_id).update({List.name:new_det['name'],List.about:new_det['about']})
			db.session.commit()
			return 'updated'
		except:
			return 'not updated'

	@token_required
	def delete(self,args,list_id):
		try:
			List.query.filter(List.user_id==self.user_id,List.list_id==list_id).one()
		
			Card.query.filter(Card.l_id==list_id).delete()
			List.query.filter(List.list_id==list_id,List.user_id==self.user_id).delete()
			db.session.commit()
			return 'List successfully deleted'
		except:
			return 'error'

class CardAPI(Resource):
	@token_required
	def get(self,args,list_id,card_id):
		try:
			lis=List.query.filter(List.user_id==self.user_id,List.list_id==list_id).one()
			det=Card.query.filter(Card.l_id==list_id,Card.card_id==card_id).one()

			return jsonify({'name':det.name,'content':det.content,'deadline':det.deadline,'completed':det.completed,'list_id':det.l_id,'list_name':lis.name})			
		except:
			return 'error'
	
	@token_required
	def post(self,args,list_id):
		try:
			lis=List.query.filter(List.user_id==self.user_id,List.list_id==list_id).one()
			new_card=request.get_json()
			record=Card(name=new_card['name'],content=new_card['content'],deadline=new_card['deadline'],l_id=list_id)
			db.session.add(record)
			db.session.commit()
			return 'created '
		except:
			return 'error'		

	@token_required
	def put(self,args,list_id,card_id):
		try:
			lis=List.query.filter(List.user_id==self.user_id,List.list_id==list_id).one()
			try:
				Card.query.filter(Card.l_id==list_id,Card.name==nam).one()
				data={"error_code":"card002","error_message":"Constraint-5 violation" }
				return data,400
			except:
				Card.query.filter(Card.card_id==card_id).update({Card.l_id:list_id})
				db.session.commit()
				return jsonify({'res':'Card moved successfully'})

		except:
			return 'error'

	@token_required
	def patch(self,args,list_id,card_id):
		try:
			print("____succ_____")
			lis=List.query.filter(List.user_id==self.user_id,List.list_id==list_id).one()
			today=date.today()
			Card.query.filter(Card.card_id==card_id,Card.l_id==list_id).update({Card.completed:str(today)})
			db.session.commit()
			return jsonify({'res':'Completed successfully'})

		except:
			return 'error'

	@token_required
	def options(self,args,list_id,card_id):
		try:
			print('____-sucess')
			det=request.get_json()
			new_name=det['name']

			new_content=det['content']

			lis=List.query.filter(List.user_id==self.user_id,List.list_id==list_id).one()
			Card.query.filter(Card.card_id==card_id,Card.l_id==list_id).update({Card.name:new_name,Card.content:new_content})
			db.session.commit()
			return jsonify({'res':'Completed successfully'})

		except:
			return 'error'		


	@token_required
	def delete(self,args,list_id,card_id):
		try:
			lis=List.query.filter(List.user_id==self.user_id,List.list_id==list_id).one()
			Card.query.filter(Card.card_id==card_id,Card.l_id==list_id).delete()
			db.session.commit()
			return jsonify({'res':'Card deleted successfully'})					
		except:
			return 'error'








api.add_resource(UserAPI,'/user/')
api.add_resource(ListAPI,'/list/','/list/<list_id>/')
api.add_resource(CardAPI,'/card/<list_id>','/card/<list_id>/<card_id>/')
