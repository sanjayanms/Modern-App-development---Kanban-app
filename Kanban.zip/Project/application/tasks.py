from application.workers import celery
from datetime import datetime
from flask import jsonify,send_file,render_template
import csv
from dateutil import parser
from datetime import datetime,date,timedelta,time
from flask_mail import Mail,Message

from application.models import User,List,Card

@celery.task()
def say_hello():
	field_names = ['No', 'Company', 'Car Model']
	  
	cars = [
	{'No': 1, 'Company': 'Ferrari', 'Car Model': '488 GTB'},
	{'No': 2, 'Company': 'Porsche', 'Car Model': '918 Spyder'},
	{'No': 3, 'Company': 'Bugatti', 'Car Model': 'La Voiture Noire'},
	{'No': 4, 'Company': 'Rolls Royce', 'Car Model': 'Phantom'},
	{'No': 5, 'Company': 'BMW', 'Car Model': 'BMW X7'},
	]
	  
	with open('exported/Names.csv', 'w') as csvfile:
	    writer = csv.DictWriter(csvfile, fieldnames = field_names)
	    writer.writeheader()
	    writer.writerows(cars)
	return 'success'

@celery.task()
def export_details(user_id):
	field_names=['list_name','list_about','card_name','card_content','card_deadline','card_completed']
	details=[]
	ls=List.query.filter(List.user_id==user_id).all()
	for x in ls:
		cd=Card.query.filter(Card.l_id==x.list_id).all()
		for y in cd:
			d={}
			d['list_name']=x.name
			d['list_about']=x.about
			d['card_name']=y.name
			d['card_content']=y.content
			d['card_deadline']=y.deadline
			d['card_completed']=y.completed
			details.append(d)	
	with open('exported/'+'summary_'+f'{user_id}'+'.csv','w') as csvfile:
		writer=csv.DictWriter(csvfile,fieldnames=field_names)
		writer.writeheader()
		writer.writerows(details)
	return 'success'	

@celery.task()
def export_list_details(user_id,list_id):
	field_names=['card_name','completed','ongoing','overdue']
	details=[]
	ls=List.query.filter(List.user_id==user_id,List.list_id==list_id ).one()
	card_det=Card.query.filter(Card.l_id==list_id).all()
	today=datetime.today()
	for y in card_det:
		print(y)
		d={}
		d['card_name']=y.name
		dead=parser.parse(y.deadline)

		if(y.completed=='no'):
			d['completed']='no'
			d['ongoing']='yes'
			if(dead>today):
				d['overdue']='no'
			else:
				d['overdue']='yes'	

		else:
			d['completed']='yes'
			d['ongoing']='no'
			d['overdue']='no'
		details.append(d)	
	with open('exported/'+'list_summary_'+f'{user_id}_{list_id}'+'.csv','w') as csvfile:
		writer=csv.DictWriter(csvfile,fieldnames=field_names)
		writer.writeheader()
		writer.writerows(details)
	return 'success'	

mail=Mail()

@celery.task()
def send_mail():
	users=User.query.all()
	last_day_of_prev_month = datetime.combine(date.today().replace(day=1) - timedelta(days=1),time(0,0))
	start_day_of_prev_month = datetime.combine(date.today().replace(day=1) - timedelta(days=last_day_of_prev_month.day),time(0,0))	
	for x in users:
		cards_completed=0
		deadline_this_month=0
		overdue_cards=0
		efficiency=0		
		lists=List.query.filter(List.user_id==x.user_id).all()
		for y in lists:
			cards=Card.query.filter(Card.l_id==y.list_id).all()
			for z in cards:

				if(z.completed!='no'):
					com=parser.parse(z.completed)
					if(com>start_day_of_prev_month and com<last_day_of_prev_month):
						cards_completed+=1
				
				dead=parser.parse(z.deadline)
				if(dead>start_day_of_prev_month and dead<last_day_of_prev_month):
					deadline_this_month+=1
					if(z.completed=='no'):
						overdue_cards+=1
		try:				
			efficiency=round(cards_completed/deadline_this_month,2)
		except:
			efficiency=0					
		data={'cards_completed':cards_completed,"deadline_this_month":deadline_this_month,"overdue_cards":overdue_cards,"efficiency":efficiency}				
		msg = Message(
	                'Monthly report',
	                sender = 'sanjayan1998ms@gmail.com',
	                recipients = [x.email],	               
	                )
		msg.body = render_template('email.html',data=data)
		msg.html = render_template('email.html',data=data)

		mail.send(msg)

	return 'Sent'


@celery.task
def daily_report():

	users=User.query.all()
	today=datetime.today()
	for x in users:
		cards_completed=0
		overdue_cards=0
		lists=List.query.filter(List.user_id==x.user_id).all()
		for y in lists:
			cards=Card.query.filter(Card.l_id==y.list_id).all()
			for z in cards:
				if(z.completed!='no'):
					comp=parser.parse(z.completed).date()
					if(comp==today.date()):
						print('today',z.name)
						cards_completed+=1
				else:
					dead=parser.parse(z.deadline)
					if(today>dead):
						overdue_cards+=1
		data={'cards_completed':cards_completed,"overdue_cards":overdue_cards}
		msg = Message(
	                'Daily report',
	                sender = 'sanjayan1998ms@gmail.com',
	                recipients = [x.email],	               
	                )
		msg.body = render_template('report.html',data=data)
		msg.html = render_template('report.html',data=data)

		mail.send(msg)
	return 'sent'	

@celery.task
def password_change_mail(user_id,password):
	usr=User.query.filter(User.user_id==user_id).one()
	msg = Message(
	        'Password changed',
	        sender = 'sanjayan1998ms@gmail.com',
	        recipients = [usr.email],	               
	        )
	msg.body = render_template('password_changed.html',password=password)
	msg.html = render_template('password_changed.html',password=password)
	mail.send(msg)
	return 'sent'

