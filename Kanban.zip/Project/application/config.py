import os

base_dir = os.path.abspath(os.path.dirname(__file__))

class Config():
	DEBUG = False
	SQLITE_DB_DIR=None
	SQLALCHEMY_DATABASE_URI=None
	SQLALCHEMY_TRACK_MODIFICATIONS=False
	SECRET_KEY='thisisthekey'
	CELERY_BROKER_URL="redis://localhost:6379/1"
	CELERY_RESULT_BACKEND="redis://localhost:6379/2"
	REDIS_URL="redis://localhost:6379"
	CACHE_TYPE="RedisCache"
	CACHE_REDIS_HOST="localhost"
	CACHE_REDIS_PORT=6379

	MAIL_SERVER='smtp.gmail.com'
	MAIL_PORT = 465
	MAIL_USERNAME = 'sanjayan1998ms@gmail.com'
	MAIL_PASSWORD = 'ijufmfrslryjuarl'
	MAIL_USE_TLS = False
	MAIL_USE_SSL = True	

class LocalDevelopmentConfig(Config):
	SQLITE_DB_DIR=os.path.join(base_dir,"../db_directory")	
	SQLALCHEMY_DATABASE_URI="sqlite:///"+os.path.join(SQLITE_DB_DIR,"kanbandb.sqlite3")
	DEBUG=True
	CELERY_BROKER_URL="redis://localhost:6379/1"
	CELERY_RESULT_BACKEND="redis://localhost:6379/2"	
	REDIS_URL="redis://localhost:6379"
	CACHE_TYPE="RedisCache"
	CACHE_REDIS_HOST="localhost"
	CACHE_REDIS_PORT=6379	

	MAIL_SERVER='smtp.gmail.com'
	MAIL_PORT = 465
	MAIL_USERNAME = 'sanjayan1998ms@gmail.com'
	MAIL_PASSWORD = 'ijufmfrslryjuarl'
	MAIL_USE_TLS = False
	MAIL_USE_SSL = True	
